@echo off
setlocal
cd /d "%~dp0"
title Kuran APK kurulum
echo ================================================
echo   Kuran APK kurulumu (internet gerekir, uzun surer)
echo ================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js bulunamadi, kuruluyor...
  winget install -e --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
  echo.
  echo Node.js kuruldu. Bu pencereyi KAPAT ve bu dosyayi tekrar calistir.
  pause
  exit /b
)

where java >nul 2>nul
if errorlevel 1 (
  echo Java bulunamadi, kuruluyor...
  winget install -e --id EclipseAdoptium.Temurin.17.JDK --accept-package-agreements --accept-source-agreements
  echo.
  echo Java kuruldu. Bu pencereyi KAPAT ve bu dosyayi tekrar calistir.
  pause
  exit /b
)

set "ANDROID_HOME=%USERPROFILE%\android-sdk"
set "ANDROID_SDK_ROOT=%ANDROID_HOME%"
if not exist "%ANDROID_HOME%\cmdline-tools\latest\bin\sdkmanager.bat" (
  echo Android arac takimi indiriliyor...
  mkdir "%ANDROID_HOME%" 2>nul
  powershell -NoProfile -Command "Invoke-WebRequest -Uri https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip -OutFile '%TEMP%\cmdtools.zip'"
  if errorlevel 1 goto hata
  powershell -NoProfile -Command "Expand-Archive -Force '%TEMP%\cmdtools.zip' '%TEMP%\cmdtools'"
  mkdir "%ANDROID_HOME%\cmdline-tools" 2>nul
  move "%TEMP%\cmdtools\cmdline-tools" "%ANDROID_HOME%\cmdline-tools\latest"
)

if not exist "%ANDROID_HOME%\platforms\android-34" (
  echo Android bilesenleri kuruluyor...
  (for /l %%i in (1,1,30) do @echo y) > "%TEMP%\yes.txt"
  call "%ANDROID_HOME%\cmdline-tools\latest\bin\sdkmanager.bat" --licenses < "%TEMP%\yes.txt"
  call "%ANDROID_HOME%\cmdline-tools\latest\bin\sdkmanager.bat" "platform-tools" "platforms;android-34" "build-tools;34.0.0"
  if errorlevel 1 goto hata
)

echo.
echo Paketler yukleniyor...
call npm install
if errorlevel 1 goto hata

echo.
echo Dosyalar hazirlaniyor (model dahil, yaklasik 100 MB iner)...
node scripts\prepare.js
if errorlevel 1 goto hata

if not exist android (
  call npx cap add android
  if errorlevel 1 goto hata
)
node scripts\patch-manifest.js
if errorlevel 1 goto hata
call npx cap sync android
if errorlevel 1 goto hata

set "SDKP=%ANDROID_HOME:\=/%"
> android\local.properties echo sdk.dir=%SDKP%

echo.
echo APK derleniyor (ilk sefer 10-30 dakika surebilir)...
cd android
call gradlew.bat assembleDebug
if errorlevel 1 goto hata
cd ..

copy /Y android\app\build\outputs\apk\debug\app-debug.apk Kuran.apk
echo.
echo ================================================
echo   BITTI. APK burada: %cd%\Kuran.apk
echo   Bu dosyayi telefonuna gonderip kur.
echo ================================================
pause
exit /b

:hata
echo.
echo HATA OLDU. Yukaridaki son kirmizi/hata mesajinin ekran goruntusunu bana gonder.
pause
exit /b 1
