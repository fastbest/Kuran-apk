// APK icin gerekli dosyalari indirir ve hazirlar: yazi tipi, Kuran tanima modeli, calistirma kutuphanesi.
const fs = require("fs"), path = require("path");
const root = path.resolve(__dirname, "..");
const www = path.join(root, "www");
const log = (...a) => console.log("[hazirla]", ...a);

async function fonts() {
  const dir = path.join(www, "fonts");
  fs.mkdirSync(dir, { recursive: true });
  if (fs.existsSync(path.join(dir, "fonts.css"))) return log("yazi tipi zaten var");
  log("Amiri yazi tipi indiriliyor...");
  const ua = "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";
  let css = await (await fetch("https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&display=swap", { headers: { "User-Agent": ua } })).text();
  const urls = [...new Set([...css.matchAll(/url\((https:[^)]+)\)/g)].map(m => m[1]))];
  let i = 0;
  for (const u of urls) {
    const name = "amiri" + i++ + (u.includes(".woff2") ? ".woff2" : ".ttf");
    fs.writeFileSync(path.join(dir, name), Buffer.from(await (await fetch(u)).arrayBuffer()));
    css = css.split(u).join("./" + name);
  }
  fs.writeFileSync(path.join(dir, "fonts.css"), css);
  log("yazi tipi hazir (" + urls.length + " dosya)");
}

async function bundle() {
  const out = path.join(www, "vendor", "transformers.bundle.js");
  fs.mkdirSync(path.join(www, "vendor", "ort"), { recursive: true });
  if (!fs.existsSync(out)) {
    log("Kutuphane paketleniyor (esbuild)...");
    const entry = path.join(__dirname, "asr-entry.js");
    fs.writeFileSync(entry, 'export { pipeline, env } from "@huggingface/transformers";\n');
    await require("esbuild").build({
      entryPoints: [entry], bundle: true, minify: true, format: "esm", platform: "browser",
      outfile: out, define: { "process.env.NODE_ENV": '"production"' }, logLevel: "warning"
    });
  }
  const ortDir = path.join(root, "node_modules", "onnxruntime-web", "dist");
  const files = fs.readdirSync(ortDir).filter(f => /^ort-wasm.*\.(wasm|mjs)$/.test(f) && !/asyncify/.test(f));
  if (!files.length) throw new Error("onnxruntime-web dosyalari bulunamadi: " + ortDir);
  for (const f of files) fs.copyFileSync(path.join(ortDir, f), path.join(www, "vendor", "ort", f));
  log("ORT dosyalari kopyalandi:", files.join(", "));
}

async function model() {
  const dir = path.join(www, "models");
  const marker = path.join(dir, "iqbalaesthetic", "Basira", "config.json");
  if (fs.existsSync(marker)) return log("model zaten var");
  log("Kuran tanima modeli indiriliyor (yaklasik 100 MB)...");
  const { pipeline, env } = await import("@huggingface/transformers");
  env.cacheDir = dir;
  env.allowLocalModels = false;
  let last = 0;
  try {
    await pipeline("automatic-speech-recognition", "iqbalaesthetic/Basira", {
      dtype: "q8",
      progress_callback: p => {
        if (p.status === "progress" && Date.now() - last > 2000) { last = Date.now(); log(p.file, Math.round(p.progress || 0) + "%"); }
      }
    });
  } catch (e) {
    log("Uyari: model yuklenirken hata (dosyalar inmis olabilir):", String(e.message || e).slice(0, 200));
  }
  if (!fs.existsSync(marker)) throw new Error("Model dosyalari indirilemedi. Internet baglantini kontrol et.");
  let total = 0;
  (function walk(d) {
    for (const f of fs.readdirSync(d)) {
      const p = path.join(d, f), s = fs.statSync(p);
      if (s.isDirectory()) walk(p);
      else { total += s.size; if (/\.onnx$/.test(f)) log("model dosyasi:", path.relative(dir, p), Math.round(s.size / 1048576) + " MB"); }
    }
  })(dir);
  log("model hazir, toplam " + Math.round(total / 1048576) + " MB");
}

(async () => {
  await fonts();
  await bundle();
  await model();
  log("TAMAM");
})().catch(e => { console.error("[hazirla] HATA:", e); process.exit(1); });
