// Android ayarlari: mikrofon ve ses dosyasi izni, buyuk bellek, durum cubugu rengi.
const fs = require("fs");
const p = "android/app/src/main/AndroidManifest.xml";
let x = fs.readFileSync(p, "utf8");
const perm = (q, extra) => { if (!x.includes('"' + q + '"')) x = x.replace("</manifest>", '    <uses-permission android:name="' + q + '"' + (extra || "") + ' />\n</manifest>'); };
perm("android.permission.RECORD_AUDIO");
perm("android.permission.MODIFY_AUDIO_SETTINGS");
perm("android.permission.READ_MEDIA_AUDIO");
perm("android.permission.READ_EXTERNAL_STORAGE", ' android:maxSdkVersion="32"');
if (!x.includes("android:largeHeap")) x = x.replace("<application", '<application android:largeHeap="true"');
if (!x.includes("android:requestLegacyExternalStorage")) x = x.replace("<application", '<application android:requestLegacyExternalStorage="true"');
fs.writeFileSync(p, x);
// Acilista ses dosyalarini okuma izni iste (telefondaki Quran klasorundeki kari paketleri icin)
const jd = "android/app/src/main/java/com/kuran/okuyucu/";
fs.writeFileSync(jd + "AudioFixPlugin.java", `package com.kuran.okuyucu;

import android.content.Context;
import android.media.AudioManager;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

// Mikrofon kapaninca ses modunu normale dondurur (yoksa medya sesi calmaz)
@CapacitorPlugin(name = "AudioFix")
public class AudioFixPlugin extends Plugin {
    @PluginMethod
    public void reset(PluginCall call) {
        try {
            AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            if (am != null) am.setMode(AudioManager.MODE_NORMAL);
        } catch (Exception e) { }
        call.resolve();
    }
}
`);
fs.writeFileSync(jd + "MainActivity.java", `package com.kuran.okuyucu;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AudioFixPlugin.class);
        super.onCreate(savedInstanceState);
        String p = Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_AUDIO" : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{p}, 42);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) am.setMode(AudioManager.MODE_NORMAL);
        } catch (Exception e) { }
    }
}
`);
// Uygulama simgesi (logo)
(function cp(src, dst) {
  if (!fs.existsSync(src)) return;
  for (const f of fs.readdirSync(src)) {
    const a = src + "/" + f, b = dst + "/" + f;
    if (fs.statSync(a).isDirectory()) { fs.mkdirSync(b, { recursive: true }); cp(a, b); } else fs.copyFileSync(a, b);
  }
})("icons/res", "android/app/src/main/res");
const bg = "android/app/src/main/res/values/ic_launcher_background.xml";
if (fs.existsSync(bg)) fs.writeFileSync(bg, fs.readFileSync(bg, "utf8").replace(/#[0-9A-Fa-f]{6}/, "#2B9DF2"));
const c = "android/app/src/main/res/values/colors.xml";
if (fs.existsSync(c)) fs.writeFileSync(c, fs.readFileSync(c, "utf8").replace(/#303F9F/gi, "#2f5a35").replace(/#3F51B5/gi, "#53955a"));
console.log("[manifest] tamam");
