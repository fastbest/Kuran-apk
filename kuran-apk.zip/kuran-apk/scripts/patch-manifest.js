// Android ayarlari: mikrofon ve ses dosyasi izni, buyuk bellek, durum cubugu rengi.
const fs = require("fs");
const p = "android/app/src/main/AndroidManifest.xml";
let x = fs.readFileSync(p, "utf8");
const perm = (q, extra) => { if (!x.includes('"' + q + '"')) x = x.replace("</manifest>", '    <uses-permission android:name="' + q + '"' + (extra || "") + ' />\n</manifest>'); };
perm("android.permission.RECORD_AUDIO");
perm("android.permission.MODIFY_AUDIO_SETTINGS");
perm("android.permission.READ_MEDIA_AUDIO");
perm("android.permission.READ_EXTERNAL_STORAGE", ' android:maxSdkVersion="32"');
if (!x.includes("android:largeHeap")) x = x.replace("<application", '<application android:largeHeap="true"');
if (!x.includes("android:requestLegacyExternalStorage")) x = x.replace("<application", '<application android:requestLegacyExternalStorage="true"');
fs.writeFileSync(p, x);
// Acilista ses dosyalarini okuma izni iste (telefondaki Quran klasorundeki kari paketleri icin)
const jd = "android/app/src/main/java/com/kuran/okuyucu/";
fs.writeFileSync(jd + "AudioFixPlugin.java", `package com.kuran.okuyucu;

import android.content.Context;
import android.media.AudioManager;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

// Mikrofon kapaninca ses modunu normale dondurur (yoksa medya sesi calmaz)
@CapacitorPlugin(name = "AudioFix")
public class AudioFixPlugin extends Plugin {
    @PluginMethod
    public void reset(PluginCall call) {
        try {
            AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            if (am != null) am.setMode(AudioManager.MODE_NORMAL);
        } catch (Exception e) { }
        call.resolve();
    }
}
`);
fs.writeFileSync(jd + "KDL.java", `package com.kuran.okuyucu;

import android.content.Context;
import android.webkit.JavascriptInterface;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

// Kari seslerini uygulamanin kendi klasorune indirir (internetsiz dinlemek icin)
public class KDL {
    private final Context ctx;
    private final AtomicInteger done = new AtomicInteger(0);
    private final AtomicInteger fail = new AtomicInteger(0);
    private volatile int total = 0;
    private volatile boolean running = false;
    private volatile boolean stop = false;
    private volatile String err = "";
    private volatile String cur = "";

    public KDL(Context c) { ctx = c; }

    private File dir(String id) { return new File(new File(ctx.getFilesDir(), "q"), id.replaceAll("[^A-Za-z0-9_.-]", "")); }

    @JavascriptInterface
    public String base() { return new File(ctx.getFilesDir(), "q").getAbsolutePath(); }

    @JavascriptInterface
    public int count(String id) {
        String[] l = dir(id).list();
        if (l == null) return 0;
        int n = 0;
        for (String s : l) if (s.endsWith(".mp3")) n++;
        return n;
    }

    @JavascriptInterface
    public String status() {
        return done.get() + "," + fail.get() + "," + total + "," + (running ? 1 : 0) + "," + err.replace(",", " ") + "," + cur;
    }

    @JavascriptInterface
    public void stop() { stop = true; }

    @JavascriptInterface
    public boolean del(String id) {
        if (running && id.equals(cur)) return false;
        File d = dir(id);
        File[] l = d.listFiles();
        if (l != null) for (File f : l) f.delete();
        return d.delete();
    }

    @JavascriptInterface
    public boolean start(final String id, String names) {
        if (running) return false;
        final String[] list = names.split(",");
        final File d = dir(id);
        d.mkdirs();
        running = true; stop = false; err = ""; cur = id;
        total = list.length; done.set(0); fail.set(0);
        new Thread(new Runnable() { public void run() {
            ExecutorService ex = Executors.newFixedThreadPool(4);
            for (final String n : list) {
                final File f = new File(d, n + ".mp3");
                if (f.exists() && f.length() > 1000) { done.incrementAndGet(); continue; }
                ex.submit(new Runnable() { public void run() {
                    if (stop) return;
                    for (int t = 0; t < 3 && !stop; t++) {
                        if (get("https://everyayah.com/data/" + id + "/" + n + ".mp3", f)) { done.incrementAndGet(); return; }
                        try { Thread.sleep(800); } catch (InterruptedException e) { }
                    }
                    if (fail.incrementAndGet() > 40) stop = true;
                }});
            }
            ex.shutdown();
            try { ex.awaitTermination(3, TimeUnit.DAYS); } catch (InterruptedException e) { }
            running = false;
        }}).start();
        return true;
    }

    private boolean get(String u, File f) {
        HttpURLConnection c = null;
        File tmp = new File(f.getPath() + ".part");
        try {
            c = (HttpURLConnection) new URL(u).openConnection();
            c.setConnectTimeout(20000);
            c.setReadTimeout(30000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) Kuran");
            int code = c.getResponseCode();
            if (code != 200) { err = "HTTP " + code; return false; }
            InputStream in = c.getInputStream();
            FileOutputStream out = new FileOutputStream(tmp);
            byte[] b = new byte[32768];
            int r;
            while ((r = in.read(b)) > 0) out.write(b, 0, r);
            out.close();
            in.close();
            if (tmp.length() < 1000) { tmp.delete(); err = "bos dosya"; return false; }
            return tmp.renameTo(f);
        } catch (Exception e) {
            err = e.getClass().getSimpleName();
            tmp.delete();
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
`);
fs.writeFileSync(jd + "MainActivity.java", `package com.kuran.okuyucu;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AudioFixPlugin.class);
        super.onCreate(savedInstanceState);
        try { getBridge().getWebView().addJavascriptInterface(new KDL(getApplicationContext()), "KDL"); } catch (Exception e) { }
        String p = Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_AUDIO" : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{p}, 42);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) am.setMode(AudioManager.MODE_NORMAL);
        } catch (Exception e) { }
    }
}
`);
// Uygulama simgesi (logo)
(function cp(src, dst) {
  if (!fs.existsSync(src)) return;
  for (const f of fs.readdirSync(src)) {
    const a = src + "/" + f, b = dst + "/" + f;
    if (fs.statSync(a).isDirectory()) { fs.mkdirSync(b, { recursive: true }); cp(a, b); } else fs.copyFileSync(a, b);
  }
})("icons/res", "android/app/src/main/res");
const bg = "android/app/src/main/res/values/ic_launcher_background.xml";
if (fs.existsSync(bg)) fs.writeFileSync(bg, fs.readFileSync(bg, "utf8").replace(/#[0-9A-Fa-f]{6}/, "#2B9DF2"));
const c = "android/app/src/main/res/values/colors.xml";
if (fs.existsSync(c)) fs.writeFileSync(c, fs.readFileSync(c, "utf8").replace(/#303F9F/gi, "#2f5a35").replace(/#3F51B5/gi, "#53955a"));
console.log("[manifest] tamam");
