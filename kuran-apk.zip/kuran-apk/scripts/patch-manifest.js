// Android ayarlari: mikrofon ve ses dosyasi izni, buyuk bellek, durum cubugu rengi.
const fs = require("fs");
const p = "android/app/src/main/AndroidManifest.xml";
let x = fs.readFileSync(p, "utf8");
const perm = (q, extra) => { if (!x.includes('"' + q + '"')) x = x.replace("</manifest>", '    <uses-permission android:name="' + q + '"' + (extra || "") + ' />\n</manifest>'); };
perm("android.permission.RECORD_AUDIO");
perm("android.permission.MODIFY_AUDIO_SETTINGS");
perm("android.permission.READ_MEDIA_AUDIO");
perm("android.permission.READ_EXTERNAL_STORAGE", ' android:maxSdkVersion="32"');
if (!x.includes("android:largeHeap")) x = x.replace("<application", '<application android:largeHeap="true"');
if (!x.includes("android:requestLegacyExternalStorage")) x = x.replace("<application", '<application android:requestLegacyExternalStorage="true"');
fs.writeFileSync(p, x);
// Acilista ses dosyalarini okuma izni iste (telefondaki Quran klasorundeki kari paketleri icin)
const m = "android/app/src/main/java/com/kuran/okuyucu/MainActivity.java";
fs.writeFileSync(m, `package com.kuran.okuyucu;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String p = Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_AUDIO" : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{p}, 42);
        }
    }
}
`);
const c = "android/app/src/main/res/values/colors.xml";
if (fs.existsSync(c)) fs.writeFileSync(c, fs.readFileSync(c, "utf8").replace(/#303F9F/gi, "#2f5a35").replace(/#3F51B5/gi, "#53955a"));
console.log("[manifest] tamam");
